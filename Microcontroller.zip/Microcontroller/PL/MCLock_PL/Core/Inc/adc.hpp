/*
 * dac.h
 *
 *  Created on: Mar 11, 2016
 *      Author: philip
 */

#ifndef ADC_H_
#define ADC_H_

#include "stm32f4xx_hal.h"
#include "newdma.hpp"
#include "oscilloscope.hpp"
#include "flashmemory.hpp"

#define ADC_BIPOLAR_10V		(uint8_t)0
#define ADC_BIPOLAR_5V		(uint8_t)1
#define ADC_UNIPOLAR_10V	(uint8_t)2
#define ADC_UNIPOLAR_5V		(uint8_t)3
#define ADC_OFF				(uint8_t)4

class ADC_Dev;

class ADC_Channel
{
private:
	ADC_Dev* ParentDevice;
	float StepSize;
	bool TwoComp;
	volatile int16_t input;
	volatile float InputFloat;
	uint8_t ChannelId, config;
	bool LowPassOn, LowPassReset;
	float LowPassWeight, LowPassPrev;
public:
	ADC_Channel(ADC_Dev* ParentDevice, uint16_t ChannelId);
	float GetFloat();
	int16_t GetInt();
	void SetInput(int16_t input);
	void Setup(uint8_t config);
	void SetLowPass(bool LowPassOn, float Weight);
	void ResetLowPass();

	friend class ADC_Dev;
	friend class Oscilloscope;
	friend class UserData;
};

class ADC_Dev
{
private:
	GPIO_TypeDef* CNV_Port;
	uint16_t CNV_Pin;
	uint8_t* Buffer;
	uint8_t* Softspan;
	volatile bool ready;
	SPI_DMA_Handler* DMAHandler;
	volatile uint8_t BufferSize;
public:
	ADC_Channel *Channel1, *Channel2;
	ADC_Dev(uint8_t SPI, uint8_t DMA_Stream_In, uint8_t DMA_Channel_In, uint8_t DMA_Stream_Out, uint8_t DMA_Channel_Out, GPIO_TypeDef* CNV_Port, uint16_t CNV_Pin);
	void Read();
	void Callback();
	void UpdateSoftSpan(uint8_t chcode, uint8_t ChannelId);
	bool isReady() { return ready; };
	bool isZero() { return (Buffer[0]==0) && (Buffer[1]==0) && (Buffer[2]==0) && (Buffer[3]==0) && (Buffer[4]==0) && (Buffer[5]==0); };
	//uint8_t* getBuffer(){return Buffer;};

	friend class Oscilloscope;
	friend class UserData;
};







#endif /* ADC_H_ */
