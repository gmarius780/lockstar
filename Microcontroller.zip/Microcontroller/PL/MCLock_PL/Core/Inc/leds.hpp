/*
 * leds.hpp
 *
 *  Created on: 25 Feb 2020
 *      Author: qo
 */

#ifndef INC_LEDS_HPP_
#define INC_LEDS_HPP_


void turn_LED1_on();
void turn_LED1_off();
void turn_LED2_on();
void turn_LED2_off();
void turn_LED3_on();
void turn_LED3_off();
void turn_LED4_on();
void turn_LED4_off();
void turn_LED5_on();
void turn_LED5_off();
void turn_LED6_on();
void turn_LED6_off();


#endif /* INC_LEDS_HPP_ */
